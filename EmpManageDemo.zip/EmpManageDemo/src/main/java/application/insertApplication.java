package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class insertApplication {
	
public static boolean insertapplication( String Name, String Email, int Phone, String Department, String Gender) {
		
		boolean isSuccess = false;
		
				//create database connection
				String url ="jdbc:mysql://localhost:3306/empmanager";
				String user = "root";
				String pass = "empmanager";
				
				
				try {
					
					Class.forName("com.mysql.jdbc.Driver");			
				    Connection con = DriverManager.getConnection(url, user, pass);		    
				    Statement stmt = con.createStatement();		    
				    String sql = "INSERT INTO aplicant values (0 , '"+ Name +"', '"+ Email + "', '"+ Phone + "','"+ Department + "','" + Gender + "' , '2020-01-01 10:10:10', 'hii') ";
				    int rs = stmt.executeUpdate(sql);	
				    
				    if(rs > 0) {
				    	isSuccess = true;
				    }   
				       				    
				}
				
				catch (Exception e) {
					e.printStackTrace();
				}
		
		
		
		return isSuccess;
	}
	
	public static List<Application> getHistory() {
		
		ArrayList<Application> application = new ArrayList<>();
		
		try {
			
			String url ="jdbc:mysql://localhost:3306/empmanager";
			String user = "root";
			String pass = "empmanager";
			Class.forName("com.mysql.jdbc.Driver");			
		    Connection con = DriverManager.getConnection(url, user, pass);		    
		    Statement stmt = con.createStatement();		 
			String sql = "select * from empmanager";
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				String a_Id = rs.getString(1);
				String Name = rs.getString(2);
				String Email = rs.getString(3);
				int Phone = rs.getInt(4);
				String Department = rs.getString(5);
				String Gender = rs.getString(6);			
							
				Application del = new Application(a_Id,  Name,  Email,  Phone,  Department,  Gender);
				application.add(del);
			}
			
		} catch (Exception e) {
			
		}
		
		return application;	
	}
	
	public static boolean deleteApplication(String aid) {
    	
    	int a_Id = Integer.parseInt(aid);
    	
    	boolean isSuccess= false;
		try {
    		
    		String url ="jdbc:mysql://localhost:3306/empmanager";
			String user = "root";
			String pass = "empmanager";
			Class.forName("com.mysql.jdbc.Driver");			
		    Connection con = DriverManager.getConnection(url, user, pass);		    
		    Statement stmt = con.createStatement();		 
    		String sql = "delete from aplicant where a_Id='"+a_Id+"'";
    		int r = stmt.executeUpdate(sql);
    		
    		if (r > 0) {
    			isSuccess = true;
    		}
    		
    	}
    	catch (Exception e) {
    		e.printStackTrace();
    	}
    	
    	return isSuccess;
    }

}
